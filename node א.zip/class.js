const express = require("express");
const app = express();
const { v4: uuidv4 } = require("uuid");
const create_new_id = uuidv4;
app.use(express.json());

const users = [
  {
    id_person: 208309856,
    name: "yaakov",
    email: "yaakov@gmail.com",
    city: "elad",
    ID: create_new_id(),
  },
  {
    id_person: 315245191,
    name: "moshe",
    email: "moshe@gmail.com",
    city: "lod",
    ID: create_new_id(),
  },
  {
    id_person: 413256745,
    name: "kobi",
    email: "kobi@gmail.com",
    city: "jerusalem",
    ID: create_new_id(),
  },
];

//פונקציה לקבלת כל המשתמשים 1
const get_all_users = () => {
  app.get("/users", (req, res) => {
    res.send(users);
  });
};
get_all_users();

//פונקציה לקבלת משתמש 1
const get_user = () => {
  app.get("/users/:id", (req, res) => {
    try {
      let id = +req.params.id;
      let user = users.find((user) => {
        return user.id_person === id;
      });
      if (user === undefined) throw new Error("not a valid id");
      res.send(user);
    } catch (error) {
      res.status(401).send(error.message);
    }
  });
};
get_user();

//פונקציה ליצירת משתמש חדש
const create_user = () => {
  app.post("/users/create", (req, res) => {
    try {
      let new_user = req.body;
      let new_id = +new_user.id_person;
      let err = users.find((user) => {
        return user.id_person === new_id;
      });
      if (err !== undefined) throw new Error(`${new_id} not valid`);
      new_user.ID = create_new_id();
      users.push(new_user);
      res.send(users);
    } catch (error) {
      res.status(406).send(error.message);
    }
  });
};
create_user();

//פונקציה לעדכון פרטים במשתמש
const edit_user = () => {
  app.put("/users/:id", (req, res) => {
    try {
      let id = +req.params.id;
      let user = users.find((user) => {
        return user.id_person === id;
      });
      if (user === undefined) throw new Error("not a valid id");
      new_data = req.body;
      Object.assign(user, new_data);
      res.send(users);
    } catch (error) {
      res.status(401).send(error.message);
    }
  });
};
edit_user();

//פונקציה למחיקת משתמש
const delete_user = () => {
  app.delete("/users/:id", (req, res) => {
    try {
      let id = +req.params.id;
      let user_id = users.findIndex((user) => {
        return user.id_person === id;
      });
      if (user_id === -1) throw new Error("not a valid id");
      users.splice(user_id, 1);
      res.send(users);
    } catch (error) {
      res.status(403).send(error.message);
    }
  });
};
delete_user();

// פונקציה לבדיקה אם אימייל קיים
const check_email = () => {
  app.post("/users/checkemail", (req, res) => {
    try {
      let new_email = req.query.email;
      let new_password = req.query.password;
      let check = users.find((user) => {
        return user.email === new_email;
      });
      if (check === undefined) throw new Error("user isn't connected");
      res.send("user is connected");
    } catch (error) {
      res.send(error.message);
    }
  });
};
check_email();

app.listen(7300, () => {
  // code
});
