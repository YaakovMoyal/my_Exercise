const itemsDal = require("../dal/itemDal");

// קבלת כל הפריטים
const get_all_items = () => {
  const items = itemsDal.get_all_items();
  return items;
};

// קבלת פריט 1
const getItem = (id) => {
  try {
    const items = itemsDal.get_all_items();
    const item = items.data.find((item) => item.id === id);
    if (item === undefined) throw new Error(`ID ${id} isn't found`);
    return item;
  } catch (error) {
    return error.message;
  }
};

// יצירת פריט חדש
const create_new_element = (data) => {
  const items = itemsDal.get_all_items();
  data.id = items.data[items.data.length - 1].id + 1;
  const new_items = itemsDal.create_new_element(data);
  return new_items;
};

// עריכת פריט קיים
const editItem = (id, new_data) => {
  try {
    const item = getItem(id);
    if (item === undefined) throw new Error(`ID ${id} isn't found`);
    const new_item = Object.assign(item, new_data);
    return new_item;
  } catch (error) {
    return error.message;
  }
};

// מחיקת פריט
const delete_item = (id) => {
  try {
    const items = itemsDal.get_all_items();
    const index_item = items.data.findIndex((item) => item.id === id);
    if (index_item === -1) {
      throw new Error(`ID ${id} isn't found`);
    }
    const new_items = itemsDal.delete_item(index_item);
    return new_items;
  } catch (error) {
    return error.message;
  }
};

module.exports = {
  get_all_items,
  getItem,
  create_new_element,
  editItem,
  delete_item,
};
