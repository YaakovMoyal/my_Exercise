const express = require("express");
const router = express.Router();

const {
  get_all_items,
  getItem,
  create_new_element,
  editItem,
  delete_item,
} = require("../controllers/itemController");

router.get("/items", get_all_items);
router.get("/item/:id", getItem);
router.post("/item", create_new_element);
router.put("/item/:id", editItem);
router.delete("/item/:id", delete_item);

module.exports = router;
