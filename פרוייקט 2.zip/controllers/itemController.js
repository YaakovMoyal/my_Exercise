const itemService = require("../services/itemService");

// קבלת כל הפריטים
const get_all_items = (req, res) => {
  const items = itemService.get_all_items();
  res.send(items);
};

// קבלת פריט 1
const getItem = (req, res) => {
  try {
    const id = +req.params.id;
    console.log(typeof id, id);
    if (isNaN(id)) {
      throw new Error(`ID ${req.params.id} isn't correct ID`);
    }
    const item = itemService.getItem(id);
    res.send(item);
  } catch (error) {
    res.status(404).send(error.message);
  }
};

// יצירת פריט חדש
const create_new_element = (req, res) => {
  const data = req.body;
  const new_items = itemService.create_new_element(data);
  res.send(new_items);
};

// עריכת פריט קיים
const editItem = (req, res) => {
  try {
    const id = +req.params.id;
    if (isNaN(id)) {
      throw new Error(`ID ${req.params.id} isn't correct ID`);
    }
    const new_data = req.body;
    const edited_item = itemService.editItem(id, new_data);
    res.send(edited_item);
  } catch (error) {
    res.status(404).send(error.message);
  }
};

// מחיקת פריט
const delete_item = (req, res) => {
  try {
    const id = +req.params.id;
    if (isNaN(id)) {
      throw new Error(`ID ${req.params.id} isn't correct ID`);
    }
    const new_items = itemService.delete_item(id);
    res.send(new_items);
  } catch (error) {
    res.status(404).send(error.message);
  }
};

module.exports = {
  get_all_items,
  getItem,
  create_new_element,
  editItem,
  delete_item,
};
