const express = require("express");
const router = require("./routes/itemRouter");
const morgan = require("morgan");
const app = express();

app.use(express.json());
app.use(express.text());
app.use(morgan("dev"));

app.use("/api", router);
app.use(express.static("public"));
app.use((req, res) => {
  res.status(900).send("page isn't found");
});

const port = 5500;

app.listen(port, () => {
  //code...
});
