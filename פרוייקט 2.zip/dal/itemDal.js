const db = require("../dataBase");

const get_all_items = () => {
  return db;
};

const getItem = (id) => {
  return db.data.id;
};

const create_new_element = (data) => {
  db.data.push(data);
  return db;
};

const editItem = (new_item) => {
  ///////  works without function !!!!!
};

const delete_item = (index_item) => {
  db.data.splice(index_item, 1);
  return db;
};

module.exports = {
  get_all_items,
  getItem,
  create_new_element,
  editItem,
  delete_item,
};
